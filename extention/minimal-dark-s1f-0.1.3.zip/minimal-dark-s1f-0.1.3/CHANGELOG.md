# Change Log

## 0.1.3 - 2020-03-11
- Changed panel color and border.

## 0.1.2 - 2020-03-11
- Changed syntax colors.
- Changed other basic colors.
