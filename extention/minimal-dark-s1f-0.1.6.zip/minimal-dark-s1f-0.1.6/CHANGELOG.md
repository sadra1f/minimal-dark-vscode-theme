# Change Log

## 0.1.6 - 2020-03-24
- Changed settings input colors.
- Changed `welcomePage.buttonHoverBackground` color.
- Added some new colors.

## 0.1.5 - 2020-03-14
- Changed notification color.
- Optimized theme for older versions of VSCode (1.31.0).

## 0.1.4 - 2020-03-12
- Improved hover colors.

## 0.1.3 - 2020-03-11
- Changed panel color and border.

## 0.1.2 - 2020-03-11
- Changed syntax colors.
- Changed other basic colors.
