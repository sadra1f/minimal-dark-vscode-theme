# Minimal Dark
A dark theme for Visual Studio Code based on vscode [theme-defaults](https://github.com/Microsoft/vscode/tree/master/extensions/theme-defaults).
* For long time coding

## Installation 
This theme is not yet available on Visual Studio Marketplace.
* Download the `.zip` file from `extention` folder and extract it
* Copy to the extention directory.
 * On Windows: `%USERPROFILE%\.vscode\extensions`
 * On Mac: `$HOME/.vscode/extensions`
* Restart the VSCode and choose `Material Dark` theme in `Preferences -> Color Theme`

