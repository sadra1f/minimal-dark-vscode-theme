# Change Log

## 0.1.2 - 2020-03-11
- Changed basic colors.
